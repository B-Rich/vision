function output = getDiags(img)
if(size(img,3) == 1)
gScaleImg = img;
else
    gScaleImg = rgb2gray(img);
end
C = getCoins(gScaleImg);
binaryImg = im2bw(imcomplement(gScaleImg),graythresh(gScaleImg));
fImg = imfill(binaryImg,'holes');
dCircles = imdilate(fImg,strel('disk',6,8));
ePLines = imerode(dCircles,strel('line',30,90));
%dCircles2 = imdilate(fImg,strel('disk',6,8));
eDLines = imerode(dCircles-ePLines,strel('line',30,-45));
figure(6), imshow(eDLines);
cImg = medfilt2(dCircles-ePLines-C);
figure(5), imshow(cImg);
buffer = zeros(size(fImg));
for idxRow = 1:1:size(fImg,1)
    for idxCol = 1:1:size(fImg,2)
            if(C(idxRow,idxCol) == 1)
                buffer(idxRow,idxCol) = 0;
            else
                buffer(idxRow,idxCol) = cImg(idxRow,idxCol);
            end
    end
end
output = buffer;
end
