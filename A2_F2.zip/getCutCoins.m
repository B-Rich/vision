function output = getUncutCoins(img,flag,type)
if(nargin < 3)
    type = 'cut';
end
if(nargin < 2)
    flag = 0;
end    
if(size(img,3) == 1)
gScaleImg = img;
else
    gScaleImg = rgb2gray(img);
end
[cntrs, rd] = imfindcircles(gScaleImg,[35 60],'ObjectPolarity','dark','Sensitivity',0.95);
mpX = cntrs(:,1);
mpY = cntrs(:,2);
intrcpt = [750 750]; %[740 740]
idxArr = zeros([1 size(rd,1)]);
for idx=1:1:size(rd,1)
    %and
    if(and(isnan(linecirc(1.37,intrcpt(1),mpX(idx),mpY(idx),rd(idx))),isnan(linecirc(1.37,intrcpt(2),mpX(idx),mpY(idx),rd(idx)))))
        idxArr(idx) = idx;
    end
    intrcpt(1)= intrcpt(1) - 173;
    intrcpt(2)= intrcpt(2) - 86;
end
idxArr(1) = 1;
[cx cy] = meshgrid(1:size(gScaleImg,2),1:size(gScaleImg,1));
cAcc = zeros(size(gScaleImg));
for idx=1:1:size(rd,1)
%     if(strcmp(type,'cut'))
%         getC = (idxArr(idx) > 0)
%     end
%     if(strcmp(type,'uncut'))
%         getC = (idxArr(idx) == 0)
%     end
%     if(getC)
    if(idxArr(idx) > 0)
    %if(idxArr(idx) == 0)
    temp = sqrt((cx-mpX(idx)).^2+(cy-mpY(idx)).^2)<=rd(idx);
    cAcc = cAcc + temp;
    end
end
%output = cAcc;
buffer = uint8(zeros(size(cAcc)));
for idxRow = 1:1:size(cAcc,1)
    for idxCol = 1:1:size(cAcc,2)
            if(cAcc(idxRow,idxCol) == 1)
                buffer(idxRow,idxCol) = img(idxRow,idxCol);
            end
    end
end
if(flag == 1)
output = buffer;
else
output = idxArr;
end
end