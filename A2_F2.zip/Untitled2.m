img = imread('A.tif');
gImg = rgb2gray(img);
bImg = im2bw(imcomplement(img),graythresh(img));
fImg = imfill(bImg,'holes');
items = bwlabel(fImg);
[hof,Theta,Ro] = hough(gImg);
hp = houghpeaks(hof);
hl = houghlines(bImg,Theta,Ro,hp);
%LINES = houghlines(BW, THETA, RHO, PEAKS) Theta and Row returned by hough
%logical(convX(filledImg));
