function newFlower = getSepalData(img)
if size(img,3) == 3
    img = rgb2gray(img);
end
bw = imerode(im2bw(img,graythresh(img)),strel('disk',3,8)); %ThreSh.1 = 0.4
L = bwlabel(bw);
%prop_struct = regionprops(L,'Centroid');
prop_struct = regionprops(bw, 'Orientation', 'MajorAxisLength', 'MinorAxisLength', 'Eccentricity', 'Centroid');
%Centroids = cat(1,prop_struct.Centroid);
imshow(bw)
hold on

phi = linspace(0,2*pi,50);
cos_phi = cos(phi);
sin_phi = sin(phi);

for idx = 1:1:length(prop_struct)
    cent_x = prop_struct(idx).Centroid(1);
    cent_y = prop_struct(idx).Centroid(2);
    a = prop_struct(idx).MajorAxisLength/2;
    b = prop_struct(idx).MinorAxisLength/2;
    theta = pi*prop_struct(idx).Orientation/180;
    R = [cos(theta) sin(theta)
        -sin(theta) cos(theta)];
    xy = [a*cos_phi; b*sin_phi];
    xy = R*xy;
    x = xy(1,:) + cent_x;
    y = xy(2,:) + cent_y;
    plot(x,y,'g','LineWidth',2);
end
hold off
maxBuff = [];
for i = 1:1:length(prop_struct)
    maxBuff(i,:) = [prop_struct(i).MajorAxisLength, prop_struct(i).MinorAxisLength];
end
maxBuff = sortrows(maxBuff);
maxBuff = maxBuff(end,:);
spatial_const = 0.125*min(size(img));
newFlower = [round(maxBuff(1)/spatial_const,1), round(maxBuff(2)/spatial_const,1)];
end