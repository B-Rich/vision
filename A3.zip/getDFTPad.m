function pad = getDFTPad(dims)
%Get proper padding of fft function

%Images are tiled in frequency domain
%Padding reduces titling effects and wrapping

pad = 2*dims;
end