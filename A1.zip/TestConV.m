function convoluted = convX(img,kernel)
%Function that pads an image applies convolution to it with a given kernel

%Get number of rows and columns of original image
[row col depth] = size(img);

paddingSize = [row+2 col+2 depth];

%making a dummy (buffer) matrix to allow zero padding the image
paddedImage = zeros(paddingSize); 

sigma = 0.5;
%sigma = std2(img);
[x,y]=meshgrid(-3:3,-3:3);
gaussKernel = round((exp(-(x.^2+y.^2)/(2*sigma*sigma))/(2*pi*sigma*sigma)),4);

%Normalize kernel
gaussKernel = gaussKernel / sum(gaussKernel(:));

ngk = gaussKernel(3:5,3:5); %Gaussian Kernel
lpk= [1 1 1; 1 -8 1; 1 1 1]; %Laplacian Kernel

for idxDepth = 1:1:size(img,3)
    for idx = 1:1:size(img,1) 
    
    %Copy contents of the original image to the padded image
    paddedImage(idx+1,2:size(paddedImage,2)-1,idxDepth) = img(idx,:,idxDepth);
    
    end
end
% %%%%%%%%%%%%%%%%%%%%%%%%%%    
%     for idx = 1:1:size(img,1) 
%     
%     %Copy contents of the original image to the padded image
%     paddedImage(idx+1,2:size(paddedImage,1)-1,1) = img(idx,:,1);
%     
%     end
%      for idx = 1:1:size(img,1) 
%     
%     %Copy contents of the original image to the padded image
%     paddedImage(idx+1,2:size(paddedImage,1)-1,2) = img(idx,:,2);
%     
%      end
%     for idx = 1:1:size(img,1) 
%     
%     %Copy contents of the original image to the padded image
%     paddedImage(idx+1,2:size(paddedImage,1)-1,3) = img(idx,:,3);
%     
%     end
% %end
% 
% %%%%%%%%%%%%%%%%%%
SoP = 0; %Sum of products variable to store new point value
if nargin < 2
    %disp('No kernel provided, using default filter "Laplacian with diagonal detection"')
    disp('No kernel provided, using default filter, identity filter')
    %kernel = [1 1 1; 1 -8 1; 1 1 1];
    kernel = double([0 0 0; 0 1 0; 0 0 0]);
end
if strcmp(kernel,'gaussian')
    kernel = ngk;
end
if strcmp(kernel,'laplacian')
    kernel = lpk;
end
output = zeros(size(img));
for idxDepth = 1:1:size(paddedImage,3)
    for idxRow = 1:1:size(paddedImage,1)-2
        for idxCol = 1:1:size(paddedImage,1)-2
            temp = paddedImage(idxRow:idxRow+2,idxCol:idxCol+2,idxDepth);
            SoP = dot(temp(:),kernel(:));
            output(idxRow,idxCol,idxDepth) = SoP;
        end
    end
end 
convoluted = output;
end