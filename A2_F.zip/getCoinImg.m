function output = getCoinImg(img)
img = imdilate(img,strel('disk',2,8));
% ErodeDiag = imerode(img,strel('line',10,0)); RETURN TO THESE IN CASE OF
% FAILURE
% ErodVert = imerode(ErodeDiag,strel('line',9,90));
ErodeDiag = imerode(img,strel('line',15,0));
ErodVert = imerode(ErodeDiag,strel('line',15,90));
CoinsImg = imdilate(ErodVert,strel('disk',2,8));
output = bwmorph(CoinsImg,'fill'); %Coins
end