function filter = highPassFilt(filtType,dim1,dim2,DNode,Flag,n)
if nargin < 6
    n = 1;
end
if nargin < 5
    Flag = 'Unshifted';
end
HpFilt = 1 - lowPassFilt(filtType,dim1,dim2,DNode,Flag,n);
filter = HpFilt;
end