function output = getUncutCoins(img)
if(size(img,3) == 1)
gScaleImg = img;
else
    gScaleImg = rgb2gray(img);
end
[cntrs, rd] = imfindcircles(gScaleImg,[35 60],'ObjectPolarity','dark','Sensitivity',0.95);
mpX = cntrs(:,1);
mpY = cntrs(:,2);
intrcpt = 740;
idxArr = zeros([1 size(rd,1)]);
for idx=1:1:size(rd,1)
    if(isnan(linecirc(1.38,intrcpt,mpX(idx),mpY(idx),rd(idx))))
        idxArr(idx) = idx;
    end
    intrcpt= intrcpt - 173;
end
[cx cy] = meshgrid(1:size(gScaleImg,2),1:size(gScaleImg,1));
cAcc = zeros(size(gScaleImg));
for idx=1:1:size(rd,1)
    if(idxArr(idx) == 0)
    temp = sqrt((cx-mpX(idx)).^2+(cy-mpY(idx)).^2)<=rd(idx);
    cAcc = cAcc + temp;
    end
end
%output = cAcc;
buffer = uint8(zeros(size(cAcc)));
for idxRow = 1:1:size(cAcc,1)
    for idxCol = 1:1:size(cAcc,2)
            if(cAcc(idxRow,idxCol) == 1)
                buffer(idxRow,idxCol) = img(idxRow,idxCol);
            end
    end
end
output = buffer;
end