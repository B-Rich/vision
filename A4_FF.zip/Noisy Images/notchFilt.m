function filter = notchFilt(filtType,dim1,dim2,DNode,shiftX,shiftY,Flag,n)

%Create notch filter at desired position
%Notch filters are narrow highpass filters that remove frequencies other
%than dc component
%Suitable for removing repetitve "Spectral" noise

if nargin < 8
    n = 1;
end

if nargin < 7
    Flag = 'Unshifted';
end

%Create desired filter
intialFilt = highPassFilt(filtType,dim1,dim2,DNode,Flag,n);

%Shift the filter using circular shift is similar to performing rotation on
%n bits
shiftFilt = circshift(intialFilt,[shiftY shiftX]);
filter = shiftFilt;
end