function output = looper(img)
cImg = getCoins(img);
vImg = getVerticals(img);
dImg = getDiagonals(img);
buffer = zeros(size(cImg));
for idxRow = 1:1:size(img,1)
    for idxCol = 1:1:size(img,2)
            if((dImg(idxRow,idxCol) == 0 | vImg(idxRow,idxCol) == 0) & cImg(idxRow,idxCol) == 1)
                buffer(idxRow,idxCol) = 1;%cImg(idxRow,idxCol);
            else
                buffer(idxRow,idxCol) = 0;
            end
    end
end
%[xout,yout] = linecirc(slope,intercpt,centerx,centery,radius)
weskha = cImg-vImg-dImg;
circlesOnDiag = cImg-dImg; %xor(cImg,dImg)
circlesOnVert = cImg-vImg;
output = xor(cImg,dImg);
end
