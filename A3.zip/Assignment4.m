img = imread('Fruit.bmp');
grayScale = rgb2gray(img);
pad = getDFTPad(size(grayScale));
FreqImg = fft2(grayScale,pad(1),pad(2));
%FreqImg = abs(FreqImg);

D0 = 0.05*pad(1);
%Filters
ILPF = lowPassFilt('Ideal',pad(1),pad(2),D0);
IHPF = highPassFilt('Ideal',pad(1),pad(2),D0);
IHPF = highPassFilt('Ideal',pad(1),pad(2),D0);
BLPF = lowPassFilt('Butterworth',pad(1),pad(2),D0);
BHPF = highPassFilt('Butterworth',pad(1),pad(2),D0);
GLPF = lowPassFilt('Gaussian',pad(1),pad(2),D0);
GHPF = highPassFilt('Gaussian',pad(1),pad(2),D0);

%filteredImg = FreqImg.*ILPF;
filteredImg = FreqImg.*BHPF;
figure, imshow(filteredImg);

spatialImg = real(ifft2(filteredImg));
spatialImg = spatialImg(1:size(grayScale,1),1:size(grayScale,2));

figure, imshow(spatialImg,[]);