conv1 = [1 2 3; 4 5 6; 7 8 9];
conv2 = [1 2 3; 4 5 6; 7 8 9];
[m n] = size(conv1);
sum = 0;
for idx = 1:1:m*n
    sum = sum + conv1(idx)*conv2(idx); %conv1 = image, conv2 = mask
end 
conv2(5) = sum;

padder = zeros([5 5]);
padder(2,2:size(padder,1)-1) = conv1(1,:);
padder(3,2:size(padder,1)-1) = conv1(2,:);
padder(4,2:size(padder,1)-1) = conv1(3,:);
%%%%%%%%%%%%%%%%%%%%%%%%
for idx = 1:1:size(conv1,1) %where conv1 is the image, and the padder is the padding matrix
padder(idx+1,2:size(padder,1)-1) = conv1(idx,:);
%padder(3,2:size(padder,1)-1) = conv1(2,:);
%padder(4,2:size(padder,1)-1) = conv1(3,:);
end
%padderXX(2:size(padderXX,1),2:size(padderXX,1)) removes all zero rows for
%padding

%rowVector = reshape(padderXX(2:6,2:6).',1,[]); reshape matrix into row for
%easier sum of products
SoP = 0;
kernel = [0 1 0; 1 -4 1; 0 1 0];
%function operates on padded image and then makes a new image after
%applying kernel
output = zeros(size(conv1)); %where conv1 is the image
for idx = 1:1:size(padder,1)-2
    temp = padder(idx:idx+2,idx:idx+2);
    %rowVectorPaddedImage = reshape(temp.',1,[]);
    SoP = dot(temp(:),kernel(:));
    output(1,idx) = SoP
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Second attempt, all matrix
for idxRow = 1:1:size(padder,1)-2
  %d = 0;
  for idxCol = 1:1:size(padder,1)-2
    Move = (idxRow:idxRow+2):(idxCol:idxCol+2); %experimental
    %temp = padder(idxRow:idxRow+2,idxRow:idxRow+2);
    %disp(Move)
    temp = padder(idxRow:idxRow+2,idxCol:idxCol+2);
    size(temp)
    %rowVectorPaddedImage = reshape(temp.',1,[]);
    SoP = dot(temp(:),kernel(:));
    output(idxRow,idxCol) = SoP;
    %d = Move;
  end
  %disp(d);
end
%working --> applies kernel to padded image and produces output
for idxRow = 1:1:size(padder,1)-2
  for idxCol = 1:1:size(padder,1)-2
    temp = padder(idxRow:idxRow+2,idxCol:idxCol+2);
    SoP = dot(temp(:),kernel(:));
    output(idxRow,idxCol) = SoP;
  end
end