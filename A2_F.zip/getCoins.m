function output = getCoins(img)
if(size(img,3) == 1)
gScaleImg = img;
else
    gScaleImg = rgb2gray(img);
end
[cntrs, rd] = imfindcircles(gScaleImg,[35 60],'ObjectPolarity','dark','Sensitivity',0.95);
[cx cy] = meshgrid(1:size(gScaleImg,2),1:size(gScaleImg,1));
cAcc = zeros(size(gScaleImg)); %accumilate circles
mpX = cntrs(:,1);
mpY = cntrs(:,2);
for idx=1:1:size(rd,1)
    %d = [cntrs(idx) cntrs(idx+1)];
    temp = sqrt((cx-mpX(idx)).^2+(cy-mpY(idx)).^2)<=rd(idx);
    cAcc = cAcc + temp;
end
output = cAcc;
figure, imshow(output);
%highlight = viscircles(cntrs,rd,'EdgeColor','b');
end
    