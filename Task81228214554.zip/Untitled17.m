im1 = imread('testcase1.jpg');%im2bw(rgb2gray(imread('testcase1.jpg')),graythresh(rgb2gray(imread('testcase1.jpg'))));
im2 = imread('testcase2.jpg');%im2bw(rgb2gray(imread('testcase2.jpg')),graythresh(rgb2gray(imread('testcase2.jpg'))));
im3 = imread('testcase3.jpg');%im2bw(rgb2gray(imread('testcase3.jpg')),graythresh(rgb2gray(imread('testcase3.jpg'))));
flrGScale = rgb2gray(imread('testcase3.jpg'));
flrKeyPts = detectFASTFeatures(flrGScale);%detectSURFFeatures(flrGScale,'MetricThreshold',600);
strPts = flrKeyPts.selectStrongest(50);
[feats, pts] = extractFeatures(flrGScale, strPts,'SURFSize',128);
%%%%%%%%%%%%%%%%%
% props = regionprops(l,'Extrema');,
% props2 = regionprops(l,'ConvexHull');,
% props3 = regionprops(l,'Perimeter');,
crnrs = detectFASTFeatures(flrGScale); %better than harris
crnrsHSV = detectHarrisFeatures(flrGScale);

%Number of corner points found
numOfPts = crnrs.Count;

crnrsX = zeros(size(numOfPts));
crnrsY = zeros(size(numOfPts));
crnrsMet = zeros(size(numOfPts));
%crnrsX = []; crnrsY = []; crnrsMet = [];

for idx = 1:1:numOfPts
     currPoint = crnrs(idx);
     crnrsX(idx) = currPoint.Location(1); %Get all X coordinates
     crnrsY(idx) = currPoint.Location(2); %Get all Y coordinates
     crnrsMet(idx) = currPoint.Metric;
end

%Get value and index of minimas and maximas
[mnX, mnXi] = getMinMax(crnrsX,'min'); 
[mnY, mnYi] = getMinMax(crnrsY,'min');
[mxX, mxXi] = getMinMax(crnrsX,'max');
[mxY, mxYi] = getMinMax(crnrsY,'max');

%Get value and index of highest metric
[mxM, mxMi] = getMinMax(crnrsMet,'max'); 

crnrs(mnXi).Metric = mxM;
crnrs(mnYi).Metric = mxM;
crnrs(mxXi).Metric = mxM;
crnrs(mxYi).Metric = mxM;


figure, imshow(flrGScale), title('Features from Accelerated Segementation Test'); hold on
%plot(crnrs.selectStrongest(50));
plot(strPts);
hold off