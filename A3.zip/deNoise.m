function output = deNoise(noisyImg)
if size(noisyImg,3) == 3
    noisyImg = rgb2gray(noisyImg);
end
Fr = fft2(double(noisyImg)); %Fr = fft2(noisyImg,256,256);
shiftedFr = fftshift(Fr); %Shift the Zero frequency (DC) component to the center
FrAbs = abs(shiftedFr); %Absolute value of fourier transfrom 
%Complex and real values are computed during the acqusition of the fourier
%transform of the function and thus we take the absolute value to get the
%magnitude
%%[cntrs, rd] = imfindcircles(FrAbs,[1 10],'ObjectPolarity','dark','Sensitivity',0.95);
%%%%%%%%%
%Filter code goes here
%%%%%%%%%%
%fdfImg = Frequency domain filtered image
clrImg = real(ifft2(fdfImg));
%real(ifft2(fft2(img))