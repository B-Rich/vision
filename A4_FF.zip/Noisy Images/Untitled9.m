[u, v] = dftGen(dim1,dim2);
D1 = sqrt((u-(W/2+U0)).^2 + (v-(H/2+V0)).^2);
D2 = sqrt((u-(W/2-U0)).^2 + (v-(H/2-V0)).^2);
if and(D1>D0,D2>D0)			
	H(u,v) =1			
else					
    H(u,v)=0
end