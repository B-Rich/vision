close all;
img = imread('Fruit.bmp');
[idx cMap] = rgb2ind(img,32);
if size(img,3) == 3
    grayScale = rgb2gray(img);
else
    grayScale = img;
end
pad = getDFTPad(size(grayScale));
FreqImg = fft2(double(grayScale),pad(1),pad(2));
VisFor = log(1+fftshift(abs(FreqImg)));
figure, imshow(VisFor,[]); 
figure, imshow(fftshift(FreqImg),[]); 
D0 = 0.07*pad(1);
str = 'Gaussian';
%F1 = lowPassFilt(str,pad(1),pad(2),D0); %WORKING CORRECTLY!!!
F1 = bandFilter(str,pad(1),pad(2),D0,200,'Reject');
%AugFilt = ones(size(F1)).*F1.*F2.*F3.*F4;
filteredImg = FreqImg.*F1;
%filteredImg = FreqImg.*filt;
%[ILPF, IHPF, BLPF, BHPF, GLPF, GHPF] = getFilter(pad(1),pad(2),D0);
figure(11), imshow(fftshift(log(1+abs(F1))),[]);
figure(12), imshow(fftshift(log(1+abs(filteredImg))),[]);
spatialImg = real(ifft2(filteredImg));
spatialImg = spatialImg(1:size(grayScale,1),1:size(grayScale,2));
% rgbImg = ind2rgb(uint8(spatialImg),cMap);
figure(8), 
subplot(1,2,1), imshow(uint8(spatialImg),[]);
subplot(1,2,2), imshow(grayScale,[]);
