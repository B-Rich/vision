function output = plotLines(img)

%Plot lines on an image using hough transform
img = rgb2gray(img);
%edgeImg = edge(img,'canny');
[hof,Theta,Ro] = hough(img);
hoffPeaks = houghpeaks(hof);
binaryImg = edge(img,'canny');
hofLines = houghlines(binaryImg,Theta,Ro,hoffPeaks,'FillGap',9,'MinLength',9);
figure, imshow(img), hold on
maxLineLen = 0;
for k = 1:length(hofLines)
   construct = [hofLines(k).point1; hofLines(k).point2];
   plot(construct(:,1),construct(:,2),'LineWidth',9,'Color','white');

   % Plot beginnings and ends of lines
   plot(construct(1,1),construct(1,2),'x','LineWidth',9,'Color','white');
   plot(construct(2,1),construct(2,2),'x','LineWidth',9,'Color','white');

   % Determine the endpoints of the longest line segment
   epLongestLine = norm(hofLines(k).point1 - hofLines(k).point2);
   if (epLongestLine > maxLineLen)
      maxLineLen = epLongestLine;
      constructLongestLine = construct;
   end
end
output = 0;
end