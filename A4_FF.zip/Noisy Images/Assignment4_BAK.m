close all;
%img = imread('Fruit.bmp');
img = imread('Apollo17.bmp'); %('Guess.bmp');
if size(img,3) == 3
    grayScale = rgb2gray(img);
else
    grayScale = img;
end
pad = getDFTPad(size(grayScale));
FreqImg = fft2(double(grayScale),pad(1),pad(2));
%FreqImg = abs(FreqImg);
VisFor = log(1+fftshift(abs(FreqImg)));
%[c, r] = imfindcircles(VisFor,[1 5])  Fruit%'ObjectPolarity','dark','Sensitivity',0.95);
[c, r] = imfindcircles(VisFor,[10 15])
%figure, imshow(VisFor,[]); %FT of image %Uncomment 11/20/2016 1:02AM
%viscircles(c,r,'EdgeColor','b');
%hold on
D0 = 0.05*pad(1);
%Filters
ILPF = lowPassFilt('Ideal',pad(1),pad(2),D0);
IHPF = highPassFilt('Ideal',pad(1),pad(2),D0);
IHPF = highPassFilt('Ideal',pad(1),pad(2),D0);
BLPF = lowPassFilt('Butterworth',pad(1),pad(2),D0);
BHPF = highPassFilt('Butterworth',pad(1),pad(2),D0);
BHPF2 = highPassFilt('Butterworth',pad(1),pad(2),D0*3);
GLPF = lowPassFilt('Gaussian',pad(1),pad(2),D0);
GHPF = highPassFilt('Gaussian',pad(1),pad(2),D0);

%%%%%%Testing%%%%%%%%
%Works like a charm
%BF = bandFilter('Butterworth'pad(1),pad(2),D0*8.5,D0*6.5,'Reject','Unshifted',5);
%revert to the above in case of going to abs again
%BF =
%bandFilter('Gaussian',pad(1),pad(2),D0*7.5,100,'Reject','Unshifted',5); 11:58AM 11/20/2016
BF = bandFilter('Ideal',pad(1),pad(2),D0*3,450,'Test','Unshifted',5); %revert 450
%BF1 = bandFilter('Butterworth',pad(1),pad(2),D0/2,D0*8.5,'Reject','Unshifted',5);
%BF2 = bandFilter('Butterworth',pad(1),pad(2),D0*9.5,D0*7.5,'Reject','Unshifted',5);
%%%%%%%%%%%%%%%%%%%%%

%figure(11), imshow(fftshift(log(1+(abs(BF)))),[]); 11:44AM 11/20/2016
figure(11), imshow(fftshift(BF))
% set(h, 'AlphaData', 0.5);
% hold off

%figure, imshow(fftshift(log(1+(abs(BF)))),[]); %Bandfilter figure %Uncomment 11/20/2016 1:02AM

%figure, imshow(im2bw(fftshift(log(1+(abs(BF))))),[]);
figure, imshow(FreqImg);
%filteredImg = FreqImg.*ILPF;
filteredImg = FreqImg.*1;
figure, imshow(filteredImg);
figure(8), imshow(fftshift(log(1+abs(filteredImg))),[]);

spatialImg = real(ifft2(filteredImg));
spatialImg = spatialImg(1:size(grayScale,1),1:size(grayScale,2));

figure, imshow(spatialImg,[]);