function filter = lowPassFilt(filtType,dim1,dim2,DNode,Flag,n)

%Low pass filter generator
%filtType = 'Ideal' | 'Butterworth' | 'Gaussian'
%DNode = distance from origin/cutoff frequency (must be positive)
%n = order (needed by Butterworth filter), affects  ringing effect

%Use dftGen to get required distances for filter (D0)
[u, v] = dftGen(dim1,dim2);

%Get distances present between the components of the filter
Dist = sqrt(u.^2 + v.^2);

switch filtType
    case 'Ideal'
        krnl = double(Dist <= DNode); 
    case 'Butterworth'
        if nargin < 6
            n = 1;
        end
        krnl = 1./(1+(Dist./DNode).^(2*n));
    case 'Gaussian'
        krnl = exp(-(Dist.^2)./(2*(DNode^2)));
    otherwise
        error('Specified filter has no matches')
end

if nargin < 5
    Flag = 'Unshifted';
end

%Shift the filter's zero frequency component
switch Flag
    case 'Shifted'
        filter = fftshift(krnl);
    case 'Unshifted'
        filter = krnl;
    otherwise
        error('Unknown flag')
end
end
        



