function filter = bandFilter(filtType,dim1,dim2,D0,D1,Type,Flag,n)
if nargin < 8
    n = 1;
end
if nargin < 7
    Flag = 'Unshifted';
end
%Smaller D = high pass D1
%Bigger D = low pass D0

% A1 = lowPassFilt(filtType,dim1,dim2,D0_1,Flag,n);
% A2 = highPassFilt(filtType,dim1,dim2,D0_2,Flag,n);
A1 = lowPassFilt(filtType,dim1,dim2,D0,Flag,n);
%A2 = highPassFilt(filtType,dim1,dim2,D1,Flag,n);
A2 = highPassFilt(filtType,dim1,dim2,D0+D1,Flag,n);
[x y] = meshgrid(1:size(A2,2),1:size(A2,1));
cX = round(max(max(x))/2);
cY = round(max(max(y))/2);
C = ifftshift(sqrt((x-cX).^2 + (y-cY).^2)<=((D1/2)+5));
%figure(88), imshow(C)
A3 = lowPassFilt(filtType,dim1,dim2,(D0+(2*D1)),Flag,n);%(D0+(2*T)),Flag,n);
% bin = im2bw(A3);
[r c] = size(C);
bFilt = A1;
for idxRow = 1:1:r
    for idxCol = 1:1:c
    if C(idxRow,idxCol) == 1
        bFilt(idxRow,idxCol) = A2(idxRow,idxCol);
    end
end
end


%bFilt = abs(A1-A2); %Not bad, swap Pass and Reject in sw

%bFilt = 512*abs(A1.*A2.*A3);
%bFilt = mat2gray(A1.*A2.*A3);
bFilt = mat2gray(abs(A1-A2));

switch Type
    case 'Reject'
        filter = double(bFilt);
    case 'Pass'
        filter = double(imcomplement(bFilt));
    case 'Test'
%         if and(D1>D0,D2>D0)			
%             H(u,v) =1;			
%         else					
%             H(u,v)=0;
%         end
        filter = mat2gray(abs(A1-A2));
    otherwise
        error('Unspecified band pass filter type');
end
end

