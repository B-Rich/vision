function output = getVerticals(img)
%Get Diagonals in image

%Image must be grayscale
if(size(img,3) == 1)
gScaleImg = img;
else
rgbImg = img; 
gScaleImg = rgb2gray(rgbImg);
end

%Convert grayscale image into binary and use proper threshold
binaryImg = im2bw(imcomplement(gScaleImg),graythresh(gScaleImg));

%Fill gaps in binary image
fImg = imfill(binaryImg,'holes');

%Structral elements used in morphology
coinMask = strel('disk',6,8);
dMask = strel('line',30,-45);
pMask = strel('line',10,90);

%Dilate diagonals(grow)
dlLImg = imdilate(fImg,dMask); %pMask

%Erode circular objects(shrink)
erdCImg = imerode(dlLImg,coinMask);

%Eroding verticals with the difference between dilated coins and eroded
%diagonal lines
strongVert = imerode(dlLImg-erdCImg,pMask); %dMask
enhanceVert = medfilt2(imdilate(strongVert,strel('line',5,-45)));
output = medfilt2(enhanceVert-getDiagonals(img),[12 12]);
end