function output = getCoinDetails(img)
%Get details of coin
locations = getCoins(img);
buffer = uint8(zeros(size(locations)));
for idxRow = 1:1:size(locations,1)
    for idxCol = 1:1:size(locations,2)
            if(locations(idxRow,idxCol) == 1)
                buffer(idxRow,idxCol) = img(idxRow,idxCol);
            end
    end
end
output = uint8(buffer);
end