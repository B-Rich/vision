close all;
%
gNotch = @(v,mu,cov) 1-exp(-0.5*sum((bsxfun(@minus,v,mu).*(cov\bsxfun(@minus,v,mu)))));
%

img = imread('Guess.bmp');
if size(img,3) == 3
    grayScale = rgb2gray(img);
else
    grayScale = img;
end
pad = getDFTPad(size(grayScale));
FreqImg = fft2(double(grayScale),pad(1),pad(2));
VisFor = log(1+fftshift(abs(FreqImg)));
%[c, r] = imfindcircles(VisFor,[5 10])
figure, imshow(VisFor,[]); 
%viscircles(c,r,'EdgeColor','b');
D0 = 0.15*pad(1);
Nx1 = 299-257;
Nx2 = 331-257;
Ny  = 315-257;
%cx+wx1;cy+wy & cx+wx2;cy+wy & cx-wx1;cy-wy & cx-wx1;cy-wy
F1 = notchFilt('Gaussian',pad(1),pad(2),D0,299,315);
F2 = notchFilt('Gaussian',pad(1),pad(2),D0,331,315);
F3 = notchFilt('Gaussian',pad(1),pad(2),D0,-299,-315);
F4 = notchFilt('Gaussian',pad(1),pad(2),D0,-331,-315);
AugFilt = ones(size(F1)).*F1.*F2.*F3.*F4;
figure(11);
subplot(2,2,1), imshow(fftshift(F1)), title('Sub 1')
subplot(2,2,2), imshow(fftshift(F2)), title('Sub 2')
subplot(2,2,3), imshow(fftshift(F3)), title('Sub 3')
subplot(2,2,4), imshow(fftshift(F4)), title('Sub 4')
filteredImg = FreqImg.*AugFilt;
%[ILPF, IHPF, BLPF, BHPF, GLPF, GHPF] = getFilter(pad(1),pad(2),D0);
figure(12), imshow(fftshift(log(1+abs(filteredImg))),[]);
spatialImg = real(ifft2(filteredImg));
spatialImg = spatialImg(1:size(grayScale,1),1:size(grayScale,2));
figure(8), imshow(spatialImg,[]);
