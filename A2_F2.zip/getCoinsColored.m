function output = getCoinsColored(img)
%RGB image
buffer = uint8(zeros(size(img)));
locations = getCoins(img);
for idxRow = 1:1:size(img,1)
    for idxCol = 1:1:size(img,2)
        for idxDepth = 1:1:size(img,3)
            if(locations(idxRow,idxCol,idxDepth) == 1)
                buffer(idxRow,idxCol,idxDepth) = img(idxRow,idxCol,idxDepth);
            end
        end
    end
end
output = uint8(buffer);
end