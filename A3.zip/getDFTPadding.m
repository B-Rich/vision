function [p1, p2] = getDFTPad(dims)
%Get proper padding of fft function

%Images are tiled in frequency domain
%Padding reduces titling effects and wrapping

