function output = getDiagonals(img)
%Get Diagonals in image

%Image must be grayscale
if(size(img,3) == 1)
gScaleImg = img;
else
rgbImg = img; 
gScaleImg = rgb2gray(rgbImg);
end

%Convert grayscale image into binary and use proper threshold
binaryImg = im2bw(imcomplement(gScaleImg),graythresh(gScaleImg));

%Fill gaps in binary image
fImg = imfill(binaryImg,'holes');

%Structral elements used in morphology
coinMask = strel('disk',6,8);
dMask = strel('line',30,-45);
pMask = strel('line',10,90);

%Dilate lines(grow)
dlLImg = imdilate(fImg,pMask); %pMask

%Erode circular objects(shrink)
erdCImg = imerode(dlLImg,coinMask);

%Eroding diagonals with the difference between dilated coins and eroded
%lines
strongDiag = imerode(dlLImg-erdCImg,dMask); %dMask
enhanceDiag = medfilt2(imdilate(strongDiag,strel('line',5,-45)));
output = enhanceDiag;
end