close all;
%
gNotch = @(v,mu,cov) 1-exp(-0.5*sum((bsxfun(@minus,v,mu).*(cov\bsxfun(@minus,v,mu)))));
%

img = imread('Guess.bmp');
if size(img,3) == 3
    grayScale = rgb2gray(img);
else
    grayScale = img;
end
pad = [256 256];%getDFTPad(size(grayScale));
FreqImg = fft2(double(grayScale),pad(1),pad(2));
VisFor = log(1+fftshift(abs(FreqImg)));
%[c, r] = imfindcircles(VisFor,[5 10])
figure, imshow(VisFor,[]); 
figure, imshow(fftshift(FreqImg),[]); 
%viscircles(c,r,'EdgeColor','b');
D0 = 0.02*pad(1);
str = 'Gaussian';
F1 = notchFilt(str,pad(1),pad(2),D0,35,-35);
F2 = notchFilt(str,pad(1),pad(2),D0,-35,-35);
F3 = notchFilt(str,pad(1),pad(2),D0,-35,35);
F4 = notchFilt(str,pad(1),pad(2),D0,35,35);
%%%%%%%%%%%
F5 = notchFilt(str,pad(1),pad(2),D0,20,0);
F6 = notchFilt(str,pad(1),pad(2),D0,-20,0);
F7 = notchFilt(str,pad(1),pad(2),D0,0,20);
F8 = notchFilt(str,pad(1),pad(2),D0,0,-20);
F9 = notchFilt(str,pad(1),pad(2),D0,30,30);
F0 = notchFilt(str,pad(1),pad(2),D0,-29,-29);
AugFilt = ones(size(F1)).*F0.*F1.*F2.*F3.*F4.*F5.*F6.*F7.*F8.*F9;
% figure(11);
% subplot(2,2,1), imshow(fftshift(F1)), title('Sub 1')
% subplot(2,2,2), imshow(fftshift(F2)), title('Sub 2')
% subplot(2,2,3), imshow(fftshift(F3)), title('Sub 3')
% subplot(2,2,4), imshow(fftshift(F4)), title('Sub 4')
% [m n] = size(FreqImg);
% filt = ones(m,n);
% sigma = 5;
% [y,x] = meshgrid(1:n, 1:m);
% X = [y(:) x(:)].';
% filt = filt .* reshape(gNotch(X,[257+Nx1;257+Ny],eye(2)*sigma^2),[m,n]);
% filt = filt .* reshape(gNotch(X,[257+Nx2;257+Ny],eye(2)*sigma^2),[m,n]);
% filt = filt .* reshape(gNotch(X,[257-Nx1;257-Ny],eye(2)*sigma^2),[m,n]);
% filt = filt .* reshape(gNotch(X,[257-Nx2;257-Ny],eye(2)*sigma^2),[m,n]);
filteredImg = FreqImg.*AugFilt;
%filteredImg = FreqImg.*filt;
%[ILPF, IHPF, BLPF, BHPF, GLPF, GHPF] = getFilter(pad(1),pad(2),D0);
figure(12), imshow(fftshift(log(1+abs(filteredImg))),[]);
spatialImg = real(ifft2(filteredImg));
spatialImg = spatialImg(1:size(grayScale,1),1:size(grayScale,2));
figure(8), 
subplot(1,2,1), imshow(uint8(spatialImg),[]);
subplot(1,2,2), imshow(grayScale,[]);
