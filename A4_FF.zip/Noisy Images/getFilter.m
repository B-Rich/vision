function [ILPF, IHPF, BLPF, BHPF, GLPF, GHPF] = getFilter(dim1,dim2,DNode,Flag,n)
if nargin < 5
    n = 1;
end
if nargin < 4
    Flag = 'Unshifted';
end
ILPF = lowPassFilt('Ideal',dim1,dim2,DNode,Flag,n);
IHPF = highPassFilt('Ideal',dim1,dim2,DNode,Flag,n);
IHPF = highPassFilt('Ideal',dim1,dim2,DNode,Flag,n);
BLPF = lowPassFilt('Butterworth',dim1,dim2,DNode,Flag,n);
BHPF = highPassFilt('Butterworth',dim1,dim2,DNode,Flag,n);
GLPF = lowPassFilt('Gaussian',dim1,dim2,DNode,Flag,n);
GHPF = highPassFilt('Gaussian',dim1,dim2,DNode,Flag,n);
end