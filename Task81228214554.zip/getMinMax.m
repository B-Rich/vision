function [val idx] = getMinMax(array,type)
if strcmp(type,'min')
    val = min(array);
    idx = find(val==array,1);
end
if strcmp(type,'max')
    val = max(array);
    idx = find(val==array,1);
end
end