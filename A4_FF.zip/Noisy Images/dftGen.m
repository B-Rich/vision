function [outU, outV] = dftGen(dim1, dim2)

%Frequency domain filter helper function

%X of meshgrid in DFT
dftU = 0:(dim1-1); 

%Y of meshgrid in DFT
dftV = 0:(dim2-1); 

%Find all non zero value indices of the meshgrid
idxEx = find(dftU > dim1/2); 
dftU(idxEx) = dftU(idxEx) - dim1;
idxWhy = find(dftV > dim2/2);
dftV(idxWhy) = dftV(idxWhy) - dim2;
%[outV outU] = meshgrid(v,u); 
%[outU outV] = meshgrid(dftU,dftV); 
[outV, outU] = meshgrid(dftV,dftU);
end