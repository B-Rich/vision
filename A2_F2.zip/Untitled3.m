close all;
rgbImg = imread('A.tif'); %Original
sobelDW = [0,-1,-2;1,0,-1;2,1,0];
 %rgbImg = convX(rgbImg,sobelDW); %Test
 %figure(1), imshow(im2bw(rgb2gray(rgbImg)));
gScaleImg = rgb2gray(rgbImg);
binaryImg = im2bw(imcomplement(gScaleImg),graythresh(gScaleImg));
%neg = imcomplement(gScaleImg);
%binaryImg = im2bw(neg,graythresh(gScaleImg));
%fImg = imfill(binaryImg,'holes'); %better than bwmorph
fImg = imfill(binaryImg,'holes');
%comp = bwconncomp(fImg);
%disp(comp);
%fImg = bwmorph(imfill(binaryImg,'holes'),'fill'); %welp
%[centers, radii] = imfindcircles(gImg,[30 60],'ObjectPolarity','dark','Sensitivity',0.95);
[centers, radii, metric] = imfindcircles(gScaleImg,[35 60],'ObjectPolarity','dark','Sensitivity',0.95);
%imshow(gScaleImg);
circle = strel('disk',6,8);
circle2 = strel('disk',1,8);
line = strel('line',9,-45);
line1 = strel('line',30,-45);
line2 = strel('line',9,90);
NoLinesImg = imerode(fImg,line);
NoCoinsImg = imerode(fImg,circle);
NoCoinImg = imerode(fImg,circle2);
%gotCashImg = imdilate(NoLinesImg,circle);
gotCashImg = imdilate(fImg,line2);
what = imerode(gotCashImg,circle);
%figure(55), imshow(what);
diagImg = NoLinesImg-NoCoinImg;
%figure(8), imshow(bwmorph(fImg,'remove'));%imshow(imerode(bwmorph(fImg,'remove'),circle2),[]);
%figure(13), imshow(gotCashImg);
%figure(14), imshow(imerode(gotCashImg-what,line)); %stronger diagonal
strongDiag = imerode(gotCashImg-what,line1);
figure(14), title('Strong Diagonal'), imshow(strongDiag);
figure, imshow(diagImg); %Lines
%figure(12), imshow(edge(diagImg,'canny'));
%figure, imshow(NoLinesImg);
%figure(5), imshow(NoCoinsImg); %Test
comp = bwconncomp(NoCoinsImg,8);
%figure(99), imshow(NoCoinsImg(comp.PixelIdxList{1}));
disp(comp);
%figure(5), imshow(NoCoinsImg);%COME BACK HERE
figure(6), imshow(bwmorph(NoCoinsImg,'fill')); %Coins
highlight = viscircles(centers,radii,'EdgeColor','w');
%figure, imshow(gotCashImg);
%-----------------------
% �	Segmentation: 
% graythresh, im2bw, hough, houghpeaks, houghlines 
% �	Morphology:  
% strel, bwmorph, bwconncomp, bwlabel, imdilate, imerode, imfill
%-----------------------
%figure, imshow(zeros(size(binaryImg)));
% for i=1:1:size(centers,1)
%     position = [centers(i) centers(i+1) centers(i)+radii(i) centers(i+1)+radii(i)];
%     hold on;
%     axis image;
%     rectangle('Position',position,'FaceColor','w','Curvature',[1 1]); %[1 1] to draw a circle
% end
%rectangle('Position',centers(1:2),'Curvature',[1 1]); %[1 1] to draw a
%circle
% highlight = viscircles(centers,radii,'EdgeColor','w');
%[centers, radii] = imfindcircles(rgbImg,[15 20]);
%[centers, radii] = imfindcircles(gImg,[30
%60],'ObjectPolarity','dark','Sensitivity',0.9); working
%[centers, radii] = imfindcircles(rgbImg,[15 20],'ObjectPolarity','dark','Sensitivity',0.9)
%viscircles(centersBright, radiiBright,'EdgeColor','b'); light
%viscircles(centersDark, radiiDark,'LineStyle','--');
%--------------------------
% img = imread('A.tif');
% gImg = rgb2gray(img);
% bImg = im2bw(imcomplement(img),graythresh(img));
% fImg = imfill(bImg,'holes');