close all;
img = imread('Apollo17.bmp');
if size(img,3) == 3
    grayScale = rgb2gray(img);
else
    grayScale = img;
end
pad = getDFTPad(size(grayScale));
FreqImg = fft2(double(grayScale),pad(1),pad(2));
VisFor = log(1+fftshift(abs(FreqImg)));
figure(888), imshow(VisFor,[])
D0 = 0.05*pad(1);
%%%%%%Testing%%%%%%%%
%Works like a charm
%BF = bandFilter('Butterworth'pad(1),pad(2),D0*8.5,D0*6.5,'Reject','Unshifted',5);
%revert to the above in case of going to abs again
%BF =
%bandFilter('Gaussian',pad(1),pad(2),D0*7.5,100,'Reject','Unshifted',5); 11:58AM 11/20/2016
BF = bandFilter('Ideal',pad(1),pad(2),D0*3,450,'Reject','Unshifted',5); %revert 450
figure(11), imshow(fftshift(BF))
figure, imshow(FreqImg);
filteredImg = FreqImg.*BF;
%filteredImg = FreqImg.*1;
figure, imshow(filteredImg);
figure(88), imshow(fftshift(log(1+abs(filteredImg))),[]);

spatialImg = real(ifft2(filteredImg));
spatialImg = spatialImg(1:size(grayScale,1),1:size(grayScale,2));

figure(8), 
subplot(1,2,1), imshow(uint8(spatialImg),[]);
subplot(1,2,2), imshow(grayScale,[]);