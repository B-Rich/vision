function output = globalThresh(img)

%Intial T, midpoint between min and max intensity values

T = 0.5*(double(min(img(:)))+double(max(img(:))));
TFound = false;

%Segment image using T

while ~TFound
    %Pixels with intensity values > T
    PixelGroup1 = img >= T; 
    %Pixels with intensity values < T
    PixelGroup2 = ~PixelGroup1; 
    %Get average intensity values and calculate new threshold
    TNew = 0.5*(mean(img(PixelGroup1))+mean(img(PixelGroup2)));
    TFound = abs(T-TNew) < 0.5;
    T = TNew;
end
output = T;
end